﻿using LEML_StudioBr.Objetos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LEML_StudioBr.Forms
{
    public partial class frmInfoElemento : Form
    {
        private Elemento ref_Element;

        public string TopText { get; private set; }
        public string BottomText { get; private set; }

        public frmInfoElemento(Elemento Ele)
        {
            InitializeComponent();
            txtWhat.Text = Ele.TopText;
            txtHow.Text = Ele.BottomText;
        }



        private void txtWhat_Enter(object sender, EventArgs e)
        {
            (sender as TextBox).BackColor = Color.LightYellow;
        }

        private void txtWhat_Leave(object sender, EventArgs e)
        {
            (sender as TextBox).BackColor = Color.White;
        }

        private void frmInfoElemento_Load(object sender, EventArgs e)
        {
            
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            if (txtWhat.Text != "" || txtWhat.Text.Length !=0)
                ref_Element.TopText = txtWhat.Text;
            else ref_Element.TopText = "Não Definido";

            if (txtHow.Text != "" || txtHow.Text.Length != 0)
                ref_Element.BottomText = txtHow.Text;
            else ref_Element.BottomText = "Não Definido";

            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtWhat.Text))
            {
                MessageBox.Show("O campo 'O que?' não pode estar vazio.", "Atenção",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtWhat.Focus();
                return;
            }

            if (string.IsNullOrEmpty(txtHow.Text))
            {
                MessageBox.Show("O campo 'Como?' não pode estar vazio.", "Atenção",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtHow.Focus();
                return;
            }

            // Atribui às propriedades
            TopText = txtWhat.Text;
            BottomText = txtHow.Text;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
