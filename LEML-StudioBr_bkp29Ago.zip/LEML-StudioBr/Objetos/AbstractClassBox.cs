﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LEML_StudioBr.Objetos
{
    public class AbstractClassBox:Box
    {
        public override string BoxType { get; set; } = "Abstract";

        public AbstractClassBox(int x, int y, string name) : base(x, y, name,0)
        {
            PositionX = x;
            PositionY = y;

            Width = 180;
            Height = 180;
            ColorBrush = Brushes.AliceBlue;
            Name = name;

            _formatCenter = new StringFormat()
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };
        }

        public AbstractClassBox(int positionX, int positionY, int width, int height, string originalName, string boxType, string colorName) : base(positionX, positionY, width, height, originalName, boxType, colorName)
        {
        }

        public AbstractClassBox() : base(0, 0, "Abstract",0)
        {
            PositionX = 0;
            PositionY = 0;

            Width = 180;
            Height = 180;
            ColorBrush = Brushes.LightSkyBlue;
            Name = string.Empty;

            _formatCenter = new StringFormat()
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };
        }

        public override void Draw(Graphics g, float zoomLevel = 1.0f)
        {
            g.TranslateTransform(PositionX, PositionY);

            g.FillRectangle(ColorBrush, 0, 0, Width, Height);
            g.FillRectangle(Brushes.Black, Width - 10, Height - 10, 10, 10);

            // Make it bold, just like in UML CD
            g.DrawString(Name, new Font("Segoe UI", 10, FontStyle.Bold | FontStyle.Italic), Brushes.Black, Width / 2, Height * 0.1f, _formatCenter);

            g.DrawLine(Pens.Black, 0, Height * 0.2f, Width, Height * 0.2f);

            g.ResetTransform();
        }

        public override void Select()
        {
            ColorBrush = Brushes.LightGray;
        }

        public override void Unselect()
        {
            ColorBrush = Brushes.AliceBlue;
            Name = OriginalName;
        }

    }
}
