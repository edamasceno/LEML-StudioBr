﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;  


namespace LEML_StudioBr.Objetos
{
    [Serializable]
    public class Canvas
    {
        private List<Box> _boxes;
        private Selection? _selection;
        private ListManipulator<Box> _manipulator;

        private List<Tuple<Box, Box, string, string, string, string>> _con = new List<Tuple<Box, Box, string, string, string, string>>();

       
        private PictureBox _pictureBox;



        public Canvas()
        {
            _boxes = new List<Box>();
            _selection = null;
            _manipulator = new ListManipulator<Box>(_boxes);
        }

      
        public void Draw(Graphics g, float zoomLevel = 1.0f)
        {
            if (_boxes == null || _boxes.Count == 0)
                return;

            // CORREÇÃO: Desenha primeiro as Boxes normais (que não são Elemento)
            foreach (var box in _boxes.Where(b => !(b is Elemento)))
            {
                box.Draw(g, zoomLevel);
            }


            foreach (var ele in _boxes.Where(ele => ele is Elemento))
            {
                ele.Draw(g, zoomLevel);
            }

            // Desenha as conexões após desenhar todas as boxes
            using (Pen p = new Pen(Color.Black, 2))
            {
                foreach (var (b1, b2, rel, relOrigin, srcCardinality, tgtCardinality) in _con)
                {
                    CheckLinesRels(b1, b2, rel, relOrigin, g, p, srcCardinality, tgtCardinality);
                }
            }


        }

        

        public Box? SelectRC(int x, int y)
        {
            Unselect();

            for (int i = _boxes.Count - 1; i >= 0; i--)
            {
                Box box = _boxes[i];
                if (box.IsInCollision(x, y))
                {
                    return box;
                }
            }

            return null;
        }

        public Box? SelectHeader(int x, int y)
        {
            Unselect();

            for (int i = _boxes.Count - 1; i >= 0; i--)
            {
                Box box = _boxes[i];
                if (box.IsInCollisionWithHeader(x, y))
                {
                    return box;
                }
            }

            return null;
        }

        public void Select(int x, int y)
        {
            Unselect();

            for (int i = _boxes.Count - 1; i >= 0; i--)
            {
                Box box = _boxes[i];
                if (box.IsInCollisionWithCorner(x, y))
                {
                    _selection = new ResizeSelection(box, x, y);

                    _manipulator.MoveToLast(i);
                    _selection.Select();
                    return;
                }
                else if (box.IsInCollision(x, y))
                {
                    _selection = new MoveSelection(box, x, y);

                    _manipulator.MoveToLast(i);
                    _selection.Select();
                    return;
                }
            }
        }

        public void Unselect()
        {
            if (_selection == null)
                return;

            _selection.Unselect();
            _selection = null;
        }

        public void Move(int x, int y)
        {
            if (_selection == null)
                return;

            _selection.Move(x, y);
        }









        public List<Box> GetBoxes() => _boxes;

        public void AddBoxToList(Box box)
        {
            _boxes.Add(box);
            //ReorderBoxes();

        }


        private void ReorderBoxes()
        {
            // Ordena: Boxes normais primeiro, Elementos por último (por cima)
            _boxes = _boxes.OrderBy(b => b is Elemento ? 1 : 0).ToList();
        }

        // Método para trazer Elemento para frente
        public void BringElementToFront(Elemento elemento)
        {
            if (_boxes.Contains(elemento))
            {
                _boxes.Remove(elemento);
                _boxes.Add(elemento); // Adiciona no final (topo da ordem de desenho)
            }
        }

        // Método para enviar Box normal para trás
        public void SendBoxToBack(Box box)
        {
            if (_boxes.Contains(box) && !(box is Elemento))
            {
                _boxes.Remove(box);
                _boxes.Insert(0, box); // Insere no início (fundo da ordem de desenho)
            }
        }



        public void RemoveBoxFromList(Box box) => _boxes.Remove(box);

        public bool DoesBoxNameExist(string name)
        {
            return _boxes.Exists(box => box.OriginalName == name);
        }
        public void AddConnection(Box b1, Box b2, string rel, string relOrigin, string srcCardinality, string tgtCardinality)
        {
            Tuple<Box, Box, string, string, string, string> connection = Tuple.Create(b1, b2, rel, relOrigin, srcCardinality, tgtCardinality);
            _con.Add(connection);
        }

        public void RemoveConnection(Box b1, Box b2)
        {
            _con.RemoveAll(conn => (conn.Item1 == b1 && conn.Item2 == b2) || (conn.Item1 == b2 && conn.Item2 == b1));
        }

        public void ClearAll()
        {
            _boxes.Clear();
            _con.Clear();
        }

        public void CheckLinesRels(Box b1, Box b2, string rel, string relOrigin, Graphics g, Pen p, string srcCardinality, string tgtCardinality)
        {
            foreach (Elemento box in _boxes)
            {
                switch (rel)
                {
                    case "Ação":
                        p.Color = Color.Black;
                        p.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                        break;

                    case "Condição":
                        p.Color = Color.Black;
                        p.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                        break;
                }

                if (b1.PositionX < b2.PositionX && b1.PositionX + b1.Width <= b2.PositionX)
                {
                    box.DrawLineB1LeftB2(b1, b2, g, p);
                }
                else if (b1.PositionX > b2.PositionX && b2.PositionX + b2.Width <= b1.PositionX)
                {
                    box.DrawLineB1RightB2(b1, b2, g, p);
                }
                else if (b1.PositionY < b2.PositionY)
                {
                    box.DrawLineB1OverB2(b1, b2, g, p);
                }
                else if (b1.PositionY > b2.PositionY)
                {
                    box.DrawLineB1UnderB2(b1, b2, g, p);
                }


                // Desenha o tipo de relação no meio da linha
                p.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                box.DrawAssociation(b1, b2, g, p, rel, relOrigin);

                /*

                if (rel == "Ação")
                {
                    
                    box.DrawAssociation(b1, b2, g, p, rel, relOrigin);
                }
                else if (rel == "Condição")
                {
                    
                    box.DrawAgregation(b1, b2, g, p, rel, relOrigin);
                }

                
                else if (rel == "Composition")
                {
                    box.DrawComposition(b1, b2, g, p, rel, relOrigin);
                }
                else if (rel == "Generalisation")
                {
                    box.DrawGeneralisation(b1, b2, g, p, rel, relOrigin);
                }
                
                */
                box.DrawMultiplicity(b1, b2, g, srcCardinality, "source");
                box.DrawMultiplicity(b1, b2, g, tgtCardinality, "target");
            }
        }


        private void DeleteSelectedBox()
        {

            foreach(Box box in _boxes)
            {
                if (box.IsSelected)
                {
                    var result = MessageBox.Show(
                    $"Deseja apagar a box '{box.OriginalName}'?",
                    "Confirmar Exclusão",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        _boxes.Remove(box);
                    }
                 }
            }
        }






    }
}
